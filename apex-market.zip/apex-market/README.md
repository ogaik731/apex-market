# APEX — Institutional Market Analyzer
## Deployment Guide (Netlify — Works in Nigeria)

---

## STEP 1 — Sign Up at Netlify
Go to: https://netlify.com → Sign Up (free, no credit card)

---

## STEP 2 — Deploy the App

### Option A: Drag & Drop (Easiest)
1. Download this ZIP file
2. Go to https://app.netlify.com
3. Drag the entire unzipped folder onto the Netlify dashboard
4. Wait 30 seconds — your site is live!

### Option B: GitHub (Recommended for updates)
1. Upload this folder to a GitHub repo
2. In Netlify → "Add new site" → "Import from Git"
3. Connect your GitHub repo → Deploy

---

## STEP 3 — Add Your Anthropic API Key (CRITICAL)

1. In your Netlify dashboard, go to your site
2. Click: **Site Configuration** → **Environment Variables**
3. Click: **Add a variable**
4. Set:
   - Key: `ANTHROPIC_API_KEY`
   - Value: `your-anthropic-api-key-here`
5. Click **Save**
6. Go to **Deploys** → **Trigger deploy** → **Deploy site**

---

## STEP 4 — Done!
Your APEX analyzer is live. The API key is 100% hidden server-side.
Nobody can see it in the browser.

---

## File Structure
```
apex-market/
├── netlify.toml              ← Netlify config
├── public/
│   └── index.html            ← The full APEX web app
└── netlify/
    └── functions/
        └── claude.js         ← Secure API proxy (hides your key)
```

---

## How It Works
Browser → Netlify Function (claude.js) → Anthropic API
Your API key only lives in Netlify's servers. Never in the browser.
